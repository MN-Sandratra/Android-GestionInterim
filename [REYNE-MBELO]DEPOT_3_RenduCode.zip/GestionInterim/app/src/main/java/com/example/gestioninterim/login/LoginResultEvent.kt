package com.example.gestioninterim.login

data class LoginResultEvent(val message: String?, val type: String?, val nom: String?)