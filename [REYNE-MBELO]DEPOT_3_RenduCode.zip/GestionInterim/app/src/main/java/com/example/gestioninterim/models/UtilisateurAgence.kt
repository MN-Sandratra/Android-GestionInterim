package com.example.gestioninterim.models

import java.io.Serializable

data class UtilisateurAgence (
    val nom: String,
) : Serializable, Utilisateur