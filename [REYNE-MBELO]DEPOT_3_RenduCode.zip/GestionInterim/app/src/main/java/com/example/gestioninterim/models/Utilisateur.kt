package com.example.gestioninterim.models

import java.io.Serializable

interface Utilisateur : Serializable {
}